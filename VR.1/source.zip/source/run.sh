#!/bin/bash
make
../run