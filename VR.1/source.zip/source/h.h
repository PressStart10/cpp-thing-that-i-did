int back();
int faced();
void clear();
bool gethelp();
void givehelp(bool a);
void exit();
std::string getic();