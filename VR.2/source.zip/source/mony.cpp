#include <iostream>
#include <unistd.h>
#include <stdlib.h>
#include "h.h"
#define NC "\e[0m"
#define RED "\e[0;31m"
#define GRN "\e[0;32m"
using namespace std;
int mony = 0;
int getmon(){
    return mony;
}
int givemon(int h){
    mony = h;
}
int mon(){
    while(true){
        clear();
        cout << ":{$" << mony << "$}: \n :: e[+$1$] :: \n :: exit ::" << endl;
        string doi = "";
        cin >> doi;
        if(doi == "exit"){
            back();
            return 0;
        }
        if(doi == "e"){
            mony ++;
        }
    }
}