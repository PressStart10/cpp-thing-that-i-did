#include <iostream>
#include <unistd.h>
#include "h.h"
#include <stdlib.h>
#define NC "\e[0m"
#define RED "\e[0;31m"
#define GRN "\e[0;32m"
#define exit "exit"
using namespace std;
bool help = true;
int monu;
string face[] = {" up \n down \n left \n right \n normal \n custom{$20$} \n exit \n help[show this]", "['_']", "['>']", "['<']", "['^']", "['v']"};
int x = 1;
string in = "";
string icon = "['_']";
string getic(){
	return icon;
}
// 5 parts {1 - 5}
bool e = false;
string temp = "";
void can(){
			clear();
			cout << "[   ]" << endl << " ^^^ " << endl << " ";
			cin >> temp;
			if(temp.length() < 3){
				e = true;
				while(e){
					clear();
					cerr << RED"ERR: character underflow" GRN<< endl;
					string tempr;
					cout << "continue[y/n] ";
					cin >> tempr;
					if(tempr == "y"){
						cout << NC;
						e = false;
						can();
					}
					else if(tempr == "n"){
						clear();
						cout << NC;
						faced();
					}
			}
			}
			else if(temp.length() > 3){
				e = true;
				while(e){
					clear();
					cerr << RED "ERR: character overflow" GRN<< endl;
					string tempr;
					cout << "continue[y/n] ";
					cin >> tempr;
					if(tempr == "y"){
						cout << NC;
						e = false;
						can();
					}
					else if(tempr == "n"){
						clear();
						cout << NC;
						faced();
					}
				}
			}
			else{
				cout << GRN "succes" NC << endl;
				icon = "[" + temp + "]";
				faced();
			}
		}
int faced(){
	monu = getmon();
	givemon(monu);
	e = false;
	help = gethelp();
	givehelp(false);
	temp = "";
	system("clear");
	cout << icon << "$" << monu << "$ \n" << endl;
	if(help == true)
		cout << face[0] << endl;
	help = false;
	cin >> in;
	if(in == "up"){
		icon = face[4];
		faced();
	}
	else if (in == "down"){
		icon = face[5];
		faced();
	}
	else if(in == "left"){
		icon = face[3];
		faced();
	}
	else if(in == "right"){
		icon = face[3 - 1];
		faced();
	}
	else if(in == "normal"){
		icon = face[1];
		faced();
	}
	else if(in == "help"){
		givehelp(true);
		faced();
	}
	else if((in == "custom") && (monu >= 20)){
		clear();
		monu -= 20;
		givemon(monu);
		can();
	}
	else if((in == "custom") && (monu < 20)){
		clear();
		cout << RED "NO MONY \n" NC;
		cin >> temp;
		if(temp == "$$PAS#ADMIN#123S"){
			can();
		}
		else{
			faced();
		}
	}
	else if(in == exit){
		system("clear");
		back();
	}
	else{
		system("clear");
		faced();
	}
}